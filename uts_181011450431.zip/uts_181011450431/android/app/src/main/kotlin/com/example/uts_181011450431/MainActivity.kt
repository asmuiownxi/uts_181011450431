package com.example.uts_181011450431

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
